export const APP_VERSION = '0.0.1';
